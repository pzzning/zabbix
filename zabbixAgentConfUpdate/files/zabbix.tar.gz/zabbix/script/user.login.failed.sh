#!/bin/bash
#zhengning
#20190108

# user login failed

/usr/bin/lastb |wc -l


