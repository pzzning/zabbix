#!/bin/bash
#zhengning
#20190124

ls -c $1 |wc -l
