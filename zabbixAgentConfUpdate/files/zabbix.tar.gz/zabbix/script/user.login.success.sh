#!/bin/bash
#zhengning
#20190108

# user login success

/usr/bin/last |grep $1 |wc -l
