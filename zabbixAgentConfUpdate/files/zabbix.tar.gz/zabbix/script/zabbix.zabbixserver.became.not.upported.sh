#!/bin/bash
#zhengning
#20181205

grep 'became not supported' /var/log/zabbix/zabbix_server.log -c

